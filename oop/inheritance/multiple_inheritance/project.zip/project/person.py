class Person:
    def sleep(self):
        return 'sleeping...'

